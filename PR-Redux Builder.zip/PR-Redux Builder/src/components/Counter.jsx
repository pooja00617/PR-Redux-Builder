import { useCallback, useMemo } from "react";
import {useSelector, useDispatch}  from "react-redux";
import { decrement, increment, reset } from "../Slices/CounterSlice";
import { useTheme } from "../context/ThemeContext";


function Counter() {

// useSelector hook : getting state from redux store.
const count = useSelector(state=>state.counter.value)


// useDispatch hook : getting dispatch function from redux.
const dispatch = useDispatch()


// useContext hook (Custom hook) :
const {state : {isDark,fontSize}} = useTheme();


// useCallback hook - memoized callback function 
const handleIncrement = useCallback(()=>{
    dispatch(increment())
},[dispatch]);

const handleDecrement = useCallback(()=>{
    dispatch(decrement())
},[dispatch]);

const handleReset = useCallback(()=>{
    dispatch(reset())
},[dispatch]);


// useMemo hook : memoized value of calculation
const doubleCount = useMemo(()=>{
    console.log("double count")
    return count * 2
},[count])


// dynamic style 
const style = {
    backgroundColor : isDark ? "black": "White" ,
    padding : "20px",
    borderRadius : "8px",
    fontSize : fontSize === "large" ? "1.2rem":"1rem",
    color : isDark ? "white" : "black"
}


  return (
    <div style={style}>
        <h2>Counter Component</h2>
        <p>Current Count : {count}</p>
        <p >Double Count (Memoized) : {doubleCount}</p>

        <button onClick={handleIncrement}>
            Increment
        </button>

        <button 
        onClick ={handleDecrement}
        >
            Decrement
        </button>
        
        <button 
        onClick ={handleReset}
        >
            Reset
        </button>
    </div>
  )
}

export default Counter
